import UIKit

class PostViewController: UIViewController {
    
    private lazy var stackContentView: UIStackView = {
        let stackView = UIStackView(frame: .zero)
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.spacing = 20
        stackView.translatesAutoresizingMaskIntoConstraints = false
        return stackView
    }()
    
    let dataProvider: DataProvider = .shared
    let imageDownloader: ImageDownloader = ImageDownloader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(stackContentView)
        setupConstraintsOnStackView()
        render(data: dataProvider.getPostContent())
    }
    
    func render(data: Document) {
        for contentNode in data.content {
            if let headingNode = contentNode as? Heading {
                let dynamicHeadingLabel = createLabel()
                dynamicHeadingLabel.attributedText = AttributedTextFactory.attributedTextForHeading(headingNode)
                stackContentView.addArrangedSubview(dynamicHeadingLabel)
            } else if let paragraphNode = contentNode as? Paragraph {
                let dynamicParagraphLabel = createLabel()
                dynamicParagraphLabel.attributedText = AttributedTextFactory.attributedTextForParagraph(paragraphNode)
                stackContentView.addArrangedSubview(dynamicParagraphLabel)
            } else if let imageNode = contentNode as? ImageNode {
                let dynamicImageView = createImageView()
                stackContentView.addArrangedSubview(dynamicImageView)
                setupConstraintsForImageView(dynamicImageView)
                imageDownloader.downloadImage(imageNode.src, .main) { image, error in
                    if let downloadedImage = image, error == nil {
                        dynamicImageView.image = downloadedImage
                    }
                }
            }
        }
    }
    
    private func setupConstraintsForImageView(_ imageView: UIImageView) {
        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalTo: stackContentView.widthAnchor, multiplier: 0.5),
            imageView.heightAnchor.constraint(equalTo: imageView.widthAnchor),
            imageView.centerXAnchor.constraint(equalTo: stackContentView.centerXAnchor)
        ])
    }
    
    private func setupConstraintsOnStackView() {
        NSLayoutConstraint.activate([
            stackContentView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            stackContentView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            stackContentView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
    
    private func createLabel() -> UILabel {
        let label = UILabel(frame: .zero)
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }
    
    private func createImageView() -> UIImageView {
        let imageView = UIImageView(frame: .zero)
        // Eye-balled it and looks like the image is roughly half the size of its containing
        // bounds and its a perfect square so we can take advantage of that.
        imageView.contentMode = .scaleAspectFit
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }
    
}

